﻿namespace hw2_point3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewN1K1 = new DataGridView();
            dataGridViewN1K2 = new DataGridView();
            dataGridViewN2K1 = new DataGridView();
            dataGridViewN2K2 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN1K1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN1K2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN2K1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN2K2).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewN1K1
            // 
            dataGridViewN1K1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewN1K1.Location = new Point(12, 36);
            dataGridViewN1K1.Name = "dataGridViewN1K1";
            dataGridViewN1K1.RowTemplate.Height = 25;
            dataGridViewN1K1.Size = new Size(433, 195);
            dataGridViewN1K1.TabIndex = 0;
            // 
            // dataGridViewN1K2
            // 
            dataGridViewN1K2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewN1K2.Location = new Point(451, 36);
            dataGridViewN1K2.Name = "dataGridViewN1K2";
            dataGridViewN1K2.RowTemplate.Height = 25;
            dataGridViewN1K2.Size = new Size(432, 195);
            dataGridViewN1K2.TabIndex = 1;
            // 
            // dataGridViewN2K1
            // 
            dataGridViewN2K1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewN2K1.Location = new Point(12, 277);
            dataGridViewN2K1.Name = "dataGridViewN2K1";
            dataGridViewN2K1.RowTemplate.Height = 25;
            dataGridViewN2K1.Size = new Size(433, 197);
            dataGridViewN2K1.TabIndex = 2;
            // 
            // dataGridViewN2K2
            // 
            dataGridViewN2K2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewN2K2.Location = new Point(451, 277);
            dataGridViewN2K2.Name = "dataGridViewN2K2";
            dataGridViewN2K2.RowTemplate.Height = 25;
            dataGridViewN2K2.Size = new Size(432, 197);
            dataGridViewN2K2.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(101, 9);
            label1.Name = "label1";
            label1.Size = new Size(231, 15);
            label1.TabIndex = 4;
            label1.Text = "Frequency distribution with N=20 and K=5";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(570, 249);
            label2.Name = "label2";
            label2.Size = new Size(237, 15);
            label2.TabIndex = 5;
            label2.Text = "Frequency distribution with N=50 and K=10";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(101, 249);
            label3.Name = "label3";
            label3.Size = new Size(231, 15);
            label3.TabIndex = 6;
            label3.Text = "Frequency distribution with N=50 and K=5";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(570, 9);
            label4.Name = "label4";
            label4.Size = new Size(237, 15);
            label4.TabIndex = 7;
            label4.Text = "Frequency distribution with N=20 and K=10";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 476);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridViewN2K2);
            Controls.Add(dataGridViewN2K1);
            Controls.Add(dataGridViewN1K2);
            Controls.Add(dataGridViewN1K1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewN1K1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN1K2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN2K1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewN2K2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewN1K1;
        private DataGridView dataGridViewN1K2;
        private DataGridView dataGridViewN2K1;
        private DataGridView dataGridViewN2K2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}