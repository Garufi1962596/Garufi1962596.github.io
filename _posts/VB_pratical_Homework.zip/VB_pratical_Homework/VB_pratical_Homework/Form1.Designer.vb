﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBoxCircle = New System.Windows.Forms.PictureBox()
        Me.PictureBoxLine = New System.Windows.Forms.PictureBox()
        Me.PictureBoxPoint = New System.Windows.Forms.PictureBox()
        Me.PictureBoxRectangle = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        CType(Me.PictureBoxCircle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxLine, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxPoint, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxRectangle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBoxCircle
        '
        Me.PictureBoxCircle.Location = New System.Drawing.Point(26, 130)
        Me.PictureBoxCircle.Name = "PictureBoxCircle"
        Me.PictureBoxCircle.Size = New System.Drawing.Size(135, 119)
        Me.PictureBoxCircle.TabIndex = 4
        Me.PictureBoxCircle.TabStop = False
        '
        'PictureBoxLine
        '
        Me.PictureBoxLine.Location = New System.Drawing.Point(220, 130)
        Me.PictureBoxLine.Name = "PictureBoxLine"
        Me.PictureBoxLine.Size = New System.Drawing.Size(121, 119)
        Me.PictureBoxLine.TabIndex = 5
        Me.PictureBoxLine.TabStop = False
        '
        'PictureBoxPoint
        '
        Me.PictureBoxPoint.Location = New System.Drawing.Point(411, 130)
        Me.PictureBoxPoint.Name = "PictureBoxPoint"
        Me.PictureBoxPoint.Size = New System.Drawing.Size(130, 119)
        Me.PictureBoxPoint.TabIndex = 6
        Me.PictureBoxPoint.TabStop = False
        '
        'PictureBoxRectangle
        '
        Me.PictureBoxRectangle.Location = New System.Drawing.Point(594, 130)
        Me.PictureBoxRectangle.Name = "PictureBoxRectangle"
        Me.PictureBoxRectangle.Size = New System.Drawing.Size(130, 119)
        Me.PictureBoxRectangle.TabIndex = 7
        Me.PictureBoxRectangle.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(245, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 31)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Line"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(446, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 31)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Point"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(63, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 31)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Circle"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(602, 50)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(122, 31)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Rectangle"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBoxRectangle)
        Me.Controls.Add(Me.PictureBoxPoint)
        Me.Controls.Add(Me.PictureBoxLine)
        Me.Controls.Add(Me.PictureBoxCircle)
        Me.Name = "Form1"
        Me.Text = "X"
        CType(Me.PictureBoxCircle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxLine, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxPoint, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxRectangle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBoxCircle As PictureBox
    Friend WithEvents PictureBoxLine As PictureBox
    Friend WithEvents PictureBoxPoint As PictureBox
    Friend WithEvents PictureBoxRectangle As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
