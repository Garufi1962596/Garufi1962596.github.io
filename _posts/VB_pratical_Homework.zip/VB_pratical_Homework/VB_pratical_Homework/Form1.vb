﻿Imports System.Windows.Forms.AxHost

Public Class Form1

    Private Sub Circle_Click(sender As Object, e As EventArgs) Handles Circle.Click
        Dim g As Graphics = PictureBoxCircle.CreateGraphics()

        ' To define the circle properties
        Dim pen As New Pen(Color.Black, 3)
        Dim radius As Integer = 50
        Dim centerX As Integer = PictureBoxCircle.Width \ 2 ' X coordinate of the center
        Dim centerY As Integer = PictureBoxCircle.Height \ 2 ' Y coordinate of the center

        ' to draw circle
        g.DrawEllipse(pen, centerX - radius, centerY - radius, radius * 2, radius * 2) 'This method is used to draw an ellipse

        ' Releases the graphics
        g.Dispose()
    End Sub

    Private Sub Line_Click(sender As Object, e As EventArgs) Handles Line.Click
        Dim g As Graphics = PictureBoxLine.CreateGraphics()

        Dim pen As New Pen(Color.Green, 3) ' to assign the color

        Dim startX As Integer = 0
        Dim startY As Integer = PictureBoxLine.Height \ 2 ' X  and Y coordinates of start point
        Dim endX As Integer = PictureBoxLine.Width
        Dim endY As Integer = PictureBoxLine.Height \ 2   ' X  and Y coordinates of end point

        g.DrawLine(pen, startX, startY, endX, endY) 'This method is used to draw a line
        g.Dispose()
    End Sub

    Private Sub Point_Click(sender As Object, e As EventArgs) Handles Point.Click
        Dim g As Graphics = PictureBoxPoint.CreateGraphics()
        Dim pen As New Pen(Color.Blue, 3) ' to assign the color

        ' to define the coordinates of the point  
        Dim x As Integer = 50
        Dim y As Integer = 50

        ' to define the rectangle size (1x1 pixels for a dot)
        Dim width As Integer = 1
        Dim height As Integer = 1

        ' to draw a point
        g.DrawRectangle(pen, x, y, width, height)


        g.Dispose()
    End Sub

    Private Sub Rectangle_Click(sender As Object, e As EventArgs) Handles Rectangle.Click
        Dim g As Graphics = PictureBoxRectangle.CreateGraphics()
        Dim pen As New Pen(Color.Red) ' to assign the color


        ' to define the coordinates of the rectangle
        Dim x As Integer = 0
        Dim y As Integer = 0

        ' to define the rectangle size 
        Dim width As Integer = PictureBoxRectangle.Width - 1
        Dim height As Integer = PictureBoxRectangle.Height / 2

        ' to draw a point
        g.DrawRectangle(pen, x, y, width, Height)


        g.Dispose()
    End Sub


End Class
