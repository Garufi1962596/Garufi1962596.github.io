﻿namespace hw4c_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel = new Panel();
            NumOfVar = new NumericUpDown();
            CreateJoinDistributionButton = new Button();
            specifyLabel = new Label();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)NumOfVar).BeginInit();
            SuspendLayout();
            // 
            // panel
            // 
            panel.AutoScroll = true;
            panel.AutoScrollMinSize = new Size(1, 1);
            panel.Location = new Point(12, 61);
            panel.MinimumSize = new Size(1, 1);
            panel.Name = "panel";
            panel.Size = new Size(898, 262);
            panel.TabIndex = 0;
            // 
            // NumOfVar
            // 
            NumOfVar.Location = new Point(326, 19);
            NumOfVar.Name = "NumOfVar";
            NumOfVar.Size = new Size(120, 23);
            NumOfVar.TabIndex = 3;
            NumOfVar.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // CreateJoinDistributionButton
            // 
            CreateJoinDistributionButton.Location = new Point(487, 23);
            CreateJoinDistributionButton.Name = "CreateJoinDistributionButton";
            CreateJoinDistributionButton.Size = new Size(117, 23);
            CreateJoinDistributionButton.TabIndex = 2;
            CreateJoinDistributionButton.Text = "Create variables";
            CreateJoinDistributionButton.UseVisualStyleBackColor = true;
            CreateJoinDistributionButton.Click += CreateJoinDistributionButton_Click;
            // 
            // specifyLabel
            // 
            specifyLabel.AutoSize = true;
            specifyLabel.Location = new Point(180, 27);
            specifyLabel.Name = "specifyLabel";
            specifyLabel.Size = new Size(101, 15);
            specifyLabel.TabIndex = 1;
            specifyLabel.Text = "variables number:";
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.AutoScrollMinSize = new Size(1, 1);
            panel1.Location = new Point(12, 324);
            panel1.MinimumSize = new Size(1, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(898, 517);
            panel1.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            ClientSize = new Size(910, 749);
            Controls.Add(panel1);
            Controls.Add(CreateJoinDistributionButton);
            Controls.Add(NumOfVar);
            Controls.Add(panel);
            Controls.Add(specifyLabel);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)NumOfVar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel;
        private Label specifyLabel;
        private Button CreateJoinDistributionButton;
        private NumericUpDown NumOfVar;
        private Panel panel1;
    }
}